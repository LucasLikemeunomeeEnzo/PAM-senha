import { Text, View, SafeAreaView, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [normal, setNormal] = useState(1);
  const [importante, setImportante] = useState(1);
  const [muitoImportante, setMuitoImportante] = useState(1);
  const [display, setDisplay] = useState("Nenhuma senha selecionada");
  function definirSenha(tipo) {
    if (tipo == "normal") {
      let num = normal+1;
      setDisplay("N0" + num);
      setNormal(num);
    }
    else if (tipo == "importante") {
      let num = importante+1;
      setDisplay("I0" + num);
      setImportante(num);
    }
    else if (tipo == "muito importante") {
      let num = muitoImportante+1;
      if (num < 10) {
        setDisplay("IM00" + num);
      } else {
        setDisplay("MI0" + num);
      }
      sertMuitoImportante(num);
    }
  }
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.password}>
        {display}
      </Text>
      <View style={styles.buttonContainer}>
        <Button title="Normal" color="green" onPress={() => definirSenha("normal")}></Button>
        <Button title="Importante" color="green" onPress={() => definirSenha("importante")}></Button>
        <Button title="Muito Importante" color="green" onPress={() => definirSenha("muito importante")}></Button>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  password: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around'
  }
});
