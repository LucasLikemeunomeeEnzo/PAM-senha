import { Text, View, SafeAreaView, StyleSheet, Button, ImageBackground } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [normal, setNormal] = useState(1);
  const [importante, setImportante] = useState(1);
  const [muitoImportante, setMuitoImportante] = useState(1);
  const [display, setDisplay] = useState("Nenhuma senha selecionada");

  function definirSenha(tipo) {
    if (tipo == "normal") {
      let num = normal + 1;
      setDisplay("N0" + num);
      setNormal(num);
    } else if (tipo == "importante") {
      let num = importante + 1;
      setDisplay("I0" + num);
      setImportante(num);
    } else if (tipo == "muito importante") {
      let num = muitoImportante + 1;
      if (num < 10) {
        setDisplay("IM00" + num);
      } else {
        setDisplay("MI0" + num);
      }
      setMuitoImportante(num);
    }
  }

  return (
    <ImageBackground 
      source={{ uri: 'https://preview.redd.it/invincible-cats-v0-gh9qs75zploe1.jpg?width=640&crop=smart&auto=webp&s=8ed668578a2efe681e64cd84c74ed6c074152a73' }} 
      style={styles.background}
    >
      <SafeAreaView style={styles.container}>
        <Text style={styles.password}>
          {display}
        </Text>
        <View style={styles.buttonContainer}>
          <View style={styles.buttonWrapper}>
            <Button title="Normal" color="#3498db" onPress={() => definirSenha("normal")} />
          </View>
          <View style={styles.buttonWrapper}>
            <Button title="Importante" color="#e67e22" onPress={() => definirSenha("importante")} />
          </View>
          <View style={styles.buttonWrapper}>
            <Button title="Muito Importante" color="#c0392b" onPress={() => definirSenha("muito importante")} />
          </View>
        </View>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)', 
    padding: 8,
  },
  password: {
    margin: 24,
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'red',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  buttonWrapper: {
    width: 120,
  }
});

